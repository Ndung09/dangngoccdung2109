package com.example.dangngocdung_2109;

import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class SubActivity extends AppCompatActivity {
    Button bt1 , bt2 , bt3 , bt4 , bt5, bt6;
    TextView tv  , tv1 , tv2 , tv3;
    EditText edt , pass  , change1 , change2;
    String tieude[] = {"Nhập tài khoản : ","Nhập Password : "};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sub);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        // nhóm đang nhap
        bt1 = findViewById(R.id.btnback);
        bt2 = findViewById(R.id.btnnext);
        bt3 = findViewById(R.id.btndnhap);
        tv = findViewById(R.id.texttkmk);
        pass = findViewById(R.id.edtpasss);
        edt = findViewById(R.id.edtotp);
        tv2 = findViewById(R.id.textView4);

        //nhóm dang ky
        change1 = findViewById(R.id.edtchange1);
        change2 = findViewById(R.id.editchange2);
        tv1 = findViewById(R.id.textView6);
        tv3 = findViewById(R.id.textdnhoi);
        bt4 = findViewById(R.id.btndky);

        // Nhóm icon cuối

        bt5 = findViewById(R.id.btniconfb);
        bt6 = findViewById(R.id.btniconit);


        tv1.setVisibility(View.GONE);
        change1.setVisibility(View.GONE);
        change2.setVisibility(View.GONE);
        tv3.setVisibility(View.GONE);
        bt4.setVisibility(View.GONE);

        pass.setVisibility(View.INVISIBLE);
         bt1.setVisibility(View.INVISIBLE);


        // khi nhấn vào Text đăng ký ?
        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              bt3.setVisibility(View.GONE);
              edt.setVisibility(View.VISIBLE);
              bt1.setVisibility(View.INVISIBLE);
              pass.setVisibility(View.GONE);
              tv2.setVisibility(View.GONE);
              change1.setVisibility(View.VISIBLE);
              bt5.setVisibility(View.GONE);
              bt6.setVisibility(View.GONE);
              bt4.setVisibility(View.VISIBLE);
              tv3.setVisibility(View.VISIBLE);
              bt2.setVisibility(View.GONE);
              tv1.setVisibility(View.VISIBLE);
              change2.setVisibility(View.VISIBLE);
            }
        });

        // khi nhấn vào Text đăng nhập ?
        tv3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                bt3.setVisibility(View.VISIBLE);
                tv2.setVisibility(View.VISIBLE);
                change1.setVisibility(View.GONE);
                bt5.setVisibility(View.VISIBLE);
                bt6.setVisibility(View.VISIBLE);
                bt4.setVisibility(View.GONE);
                tv3.setVisibility(View.GONE);
                bt2.setVisibility(View.VISIBLE);
                tv1.setVisibility(View.GONE);
                change2.setVisibility(View.GONE);
            }
        });

        // khi nhấn vào nút back
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pass.setVisibility(View.INVISIBLE);
                edt.setVisibility(View.VISIBLE);
                tv.setText(tieude[0]);
                bt2.setVisibility(View.VISIBLE);
                bt1.setVisibility(View.INVISIBLE);
            }
        });

        // khi nhấn vào nút next
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( !edt.getText().toString().equals(""))
                {
                    edt.setVisibility(View.INVISIBLE);
                    pass.setVisibility(View.VISIBLE);
                    bt1.setVisibility(View.VISIBLE);
                    tv.setText(tieude[1]);
                    bt2.setVisibility(View.INVISIBLE);
                }
            }
        });

        // khi nhấn vào nút đăng nhập
        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if ( bt2.getVisibility() == 4 && !pass.getText().toString().equals(""))
                {
                    String a = "Bạn đã đăng nhập tài khoản : " + edt.getText().toString() + " và passwword : " + pass.getText().toString();
                    Toast.makeText(SubActivity.this,a , Toast.LENGTH_LONG).show();
                }
            }
        });

        // Khi nhấn núp đăng  ký
         bt4.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 if ( !edt.getText().toString().equals("") && !change1.getText().toString().equals("") &&!change2.getText().toString().equals("")  )
                 {
                     if (change1.getText().toString().equals(change2.getText().toString()))
                     {
                         String a = "Bạn đã đăng ký tài khoản : " + edt.getText().toString() + " và passwword : " + change1.getText().toString();
                         Toast.makeText(SubActivity.this,a , Toast.LENGTH_LONG).show();
                     }
                     else
                     {
                         Toast.makeText(SubActivity.this,"Vui lòng nhập 2 mật khẩu giống nhau !", Toast.LENGTH_SHORT).show();
                     }
                 }
                 else
                 {
                     Toast.makeText(SubActivity.this,"Vui lòng nhập đầy đủ thông tin !", Toast.LENGTH_SHORT).show();
                 }

             }
         });
    }
}